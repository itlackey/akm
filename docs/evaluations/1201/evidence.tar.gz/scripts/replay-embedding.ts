import {readFileSync} from 'node:fs';
const saved=JSON.parse(readFileSync(process.env.REPLAY_VECTOR!,'utf8'));
globalThis.fetch=async (input,init)=>{
 if(!String(input).includes('/embeddings') || JSON.stringify(JSON.parse(String(init?.body)))!==JSON.stringify(saved.request)) throw Error('Unexpected request during fixed-vector replay');
 return new Response(JSON.stringify(saved.response),{status:200,headers:{'Content-Type':'application/json'}});
};
