import {readFileSync,writeFileSync} from 'node:fs';
import {createSandbox,writeConfig,runAkm} from './lib/akm/akm.ts';
import {load} from './evals/retrieval/src/akm.ts';
const sb=createSandbox('1201-defaults');
writeConfig(sb,{configVersion:'0.9.0',registries:[]});
sb.cmd=['bun','/tmp/akm-1201-baseline/src/cli.ts'];
await load(sb,'/tmp/akm-eval-1201/corpus/library');
const results=[];
for(const build of ['baseline','candidate']) {
 sb.cmd=['bun',build==='baseline'?'/tmp/akm-1201-baseline/src/cli.ts':'<candidate>/src/cli.ts'];
 for(const query of ['thanks, that worked!','ok sounds good, go ahead','hey, are you still there?','a table keeps splitting across two pages in my book layout','Terraform remote state locking with DynamoDB']) {
  for(let trial=0;trial<3;trial++) {
   const out=await runAkm(sb,['curate','--pack','4000','--detail','agent','--format','json','--',query]);
   results.push({build,query,trial,...out,stdout:JSON.parse(out.stdout)});
  }
 }
}
writeFileSync('/tmp/akm-1201-evidence/defaults.json',JSON.stringify({sandbox:sb.dir,config:JSON.parse(readFileSync(sb.dir+'/config/config.json','utf8')),results},null,2));
console.log(sb.dir);
