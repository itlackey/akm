from pathlib import Path
import json
p=Path('/tmp/akm-eval-1201/private/retrieval/1201-final');p.mkdir(parents=True,exist_ok=True)
assets={
'knowledge/aurora-focus':({'description':'Aurora telescope thermal focus drift: blurry stars after sunset.','xrefs':['knowledge/aurora-calibration','memories/aurora-calibration-old']},'# Thermal focus adjustment\n\nFor blurry stars after sunset, wait for thermal equilibrium, then adjust focus on a reference star. Use the calibration reference to verify the reticle after the focus adjustment.'),
'knowledge/aurora-calibration':({'description':'Aurora telescope reticle calibration reference after thermal focus adjustment.','beliefState':'active'},'# Reticle calibration\n\nRecord the reference star position at the center of the reticle. Verify alignment after thermal focus adjustment. Keep both the focus procedure and calibration record.'),
'memories/aurora-calibration-old':({'description':'Aurora telescope calibration obsolete fixed focus method.','beliefState':'superseded'},'# Old calibration\n\nHistorical procedure: lock focus before sunset and skip reticle verification. Superseded by the current calibration reference.'),
'knowledge/aurora-colors':({'description':'Aurora telescope photo color balance and display saturation.'},'# Color balance\n\nAdjust display saturation for aurora photographs. This display setting does not correct telescope focus or reticle alignment.'),
'knowledge/console-handshake':({'description':'Hello startup console handshake prints hello, thank you, okay sounds good and ready when you are.'},'# Startup handshake\n\nThe console prints hello during its startup handshake and accepts the diagnostic strings thank you, okay sounds good and ready when you are. This is a protocol reference, not a reply to conversational turns.'),
}
for ref,(fm,body) in assets.items():
 f=p/'library'/f'{ref}.md';f.parent.mkdir(parents=True,exist_ok=True);f.write_text('---\n'+'\n'.join(f'{k}: {json.dumps(v)}' for k,v in fm.items())+'\n---\n\n'+body+'\n')
qs=[('f01','Hello!','chitchat'),('f02','THANK YOU!!','chitchat'),('f03','Okay, sounds good.','chitchat'),('f04','Hi, ready when you are.','chitchat'),('f05','Hello, the telescope focus drifts after sunset; find the thermal adjustment procedure and its calibration reference.','multi'),('f06','Thank you, find both the Aurora focus adjustment and the reticle calibration reference.','multi'),('f07','Hi, why are star images blurry after sunset?','symptom'),('f08','okay to skip reticle verification after telescope focus adjustment?','task'),('f09','hello startup console handshake','task'),('f10','Aurora telescope photo color balance','task'),('f11','configure an underwater sonar array','no-answer')]
with (p/'queries.jsonl').open('w') as f:
 for i,q,k in qs:f.write(json.dumps(dict(id=i,query=q,kind=k))+'\n')
with (p/'qrels.jsonl').open('w') as f:
 for i,q,k in qs:
  if k=='chitchat':continue
  for ref in assets:
   grade=3 if (i in ['f05','f06','f07','f08'] and ref=='knowledge/aurora-focus') or (i=='f09' and ref=='knowledge/console-handshake') or (i=='f10' and ref=='knowledge/aurora-colors') else 2 if i in ['f05','f06','f07','f08'] and ref=='knowledge/aurora-calibration' else 0
   f.write(json.dumps(dict(id=i,ref=ref,grade=grade,reason='Author judgment: evidence answers the explicit task' if grade else 'Does not answer this task; obsolete procedure is never current support.',judge='codex-review',**({'banned':True} if ref=='memories/aurora-calibration-old' else {})))+'\n')
