import {cpSync,readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {sandboxIn} from './lib/akm/akm.ts';
import {ask} from './evals/retrieval/src/akm.ts';
import {parseQueries,parseQrels,casesOf} from './evals/retrieval/src/lib.ts';
import {makeRow} from './evals/retrieval/src/score.ts';
const dir='/tmp/akm-1201-same-index';
cpSync('/tmp/akm-eval-1201/.cache/akm-index/retrieval-public-library',dir,{recursive:true});
const sb=sandboxIn(dir),rows=[];
sb.env.AKM_BUNDLE_DIR='/tmp/akm-eval-1201/.cache/akm-index/retrieval-public-library/bundle';
const hash=()=>createHash('sha256').update(readFileSync(dir+'/data/index.db')).digest('hex');
const before=hash();
const cs=casesOf(parseQueries(readFileSync('evals/retrieval/assets/queries.jsonl','utf8')),parseQrels(readFileSync('evals/retrieval/assets/qrels.jsonl','utf8')));
for (const id of ['q008','q020','q059','q061','q088']) {
 const c=cs.find(x=>x.id===id)!;
 for(let trial=0;trial<2;trial++) for(const build of trial===0?['baseline','candidate']:['candidate','baseline']) {
  sb.cmd=['bun',build==='baseline'?'/tmp/akm-1201-baseline/src/cli.ts':'<candidate>/src/cli.ts'];
  const a=await ask(sb,'curate',c.query,10,'semantic');
  rows.push({build,trial,answer:a,row:makeRow(c,{search:{refs:[],seconds:0},curate:{refs:a.refs,seconds:a.seconds,...(a.error?{error:a.error}:{})}})});
 }
}
writeFileSync('/tmp/akm-1201-evidence/same-index.json',JSON.stringify({before,after:hash(),rows},null,2));
console.log('same-index observations:',rows.length,'index hash unchanged:',before===hash());
