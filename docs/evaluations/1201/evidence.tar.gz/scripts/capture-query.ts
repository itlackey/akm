import {writeFileSync} from 'node:fs';
import {sandboxIn,runAkm} from './lib/akm/akm.ts';
const sb=sandboxIn('/tmp/akm-1201-same-index');
sb.env.AKM_BUNDLE_DIR='/tmp/akm-eval-1201/.cache/akm-index/retrieval-public-library/bundle';
const rows=[];
for(const build of ['baseline','candidate']) for(let trial=0;trial<2;trial++) {
 sb.cmd=['bun','--preload','/tmp/akm-1201-evidence/capture-embedding.ts',build==='baseline'?'/tmp/akm-1201-baseline/src/cli.ts':'<candidate>/src/cli.ts'];
 sb.env.PROBE_CAPTURE=`/tmp/akm-1201-evidence/q008-vector-${build}-${trial}.json`;
 const out=await runAkm(sb,['curate','--limit','10','--detail','agent','--format','json','--','prove nothing else calls this old function before I remove it']);
 rows.push({build,trial,...out,stdout:JSON.parse(out.stdout)});
}
writeFileSync('/tmp/akm-1201-evidence/q008-captured-results.json',JSON.stringify(rows,null,2));
