import {writeFileSync} from 'node:fs';
import {sandboxIn,runAkm} from './lib/akm/akm.ts';
const sb=sandboxIn('/tmp/akm-1201-same-index');
sb.env.AKM_BUNDLE_DIR='/tmp/akm-eval-1201/.cache/akm-index/retrieval-public-library/bundle';
const rows=[];
for(const vector of ['baseline-0','baseline-1','candidate-0','candidate-1']) {
 const pair=[];
 for(const build of ['baseline','candidate']) {
  sb.cmd=['bun','--preload','/tmp/akm-1201-evidence/replay-embedding.ts',build==='baseline'?'/tmp/akm-1201-baseline/src/cli.ts':'<candidate>/src/cli.ts'];
  sb.env.REPLAY_VECTOR='/tmp/akm-1201-evidence/q008-vector-'+vector+'.json';
  const out=await runAkm(sb,['curate','--limit','10','--detail','agent','--format','json','--','prove nothing else calls this old function before I remove it']);
  if(out.code) throw Error(out.stderr);
  const result=JSON.parse(out.stdout);if(result.searchMode!=='semantic')throw Error('not semantic');
  pair.push(result.items.map((x:any)=>x.ref));rows.push({vector,build,...out,stdout:result});
 }
 if(JSON.stringify(pair[0])!==JSON.stringify(pair[1]))throw Error('fixed-vector mismatch');
}
writeFileSync('/tmp/akm-1201-evidence/vector-replay.json',JSON.stringify(rows,null,2));
console.log('4 captured q008 vectors replayed through both builds; all ref lists identical for each fixed response; zero network calls');
