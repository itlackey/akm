import json,glob,statistics,hashlib
from pathlib import Path
root=Path('/tmp/akm-eval-1201/evals/retrieval/results');out={}
for col in ['library','books']:
 def rows(build):return [json.loads(x) for x in (root/f'2026-10-21-1201-{build}-hybrid-{col}-rescored-2/samples.jsonl').read_text().splitlines()]
 aa,bb=rows('baseline'),rows('candidate');summary={}
 for build in ['baseline','candidate']:
  s=json.loads((root/f'2026-10-21-1201-{build}-hybrid-{col}-rescored-2/summary.json').read_text());summary[build]={k:s[k] for k in ['n_queries','n_scored','n_errored','timeouts','status','search_mode','config','metrics','abstention','index_seconds','wall_seconds'] if k in s}
 changed=[];losses=[];missing=set()
 for a,b in zip(aa,bb):
  for sys in ['search','curate','semantic_search','semantic_curate']:
   if a[sys]['refs']!=b[sys]['refs']:
    r=dict(id=a['id'],query=a['query'],system=sys,before=a[sys]['refs'],after=b[sys]['refs'],before_scores=a[sys].get('scores'),after_scores=b[sys].get('scores'))
    changed.append(r)
    if a[sys].get('scores') and b[sys].get('scores') and b[sys]['scores']['recall_10']<a[sys]['scores']['recall_10']:losses.append(r)
 out[col]=dict(summary=summary,changed=changed,recall_losses=losses)
 print(col)
 for b,s in summary.items():print(b,{sys:(x['ndcg_10'],x['recall_10'],x['success_5'],x['judged_10']) for sys,x in s['metrics'].items()})
 print('recall losses',[(r['id'],r['system'],r['before_scores']['recall_10'],r['after_scores']['recall_10']) for r in losses])
 for b,rs in [('baseline',aa),('candidate',bb)]:print(b,'median s',{sys:statistics.median(r[sys]['seconds'] for r in rs) for sys in ['search','curate','semantic_search','semantic_curate']})
Path('/tmp/akm-1201-evidence/comparison.json').write_text(json.dumps(out,indent=2))
