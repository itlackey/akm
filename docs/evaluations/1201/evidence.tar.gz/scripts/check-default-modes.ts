import {readFileSync,writeFileSync} from 'node:fs';
import {sandboxIn,runAkm} from './lib/akm/akm.ts';
const saved=JSON.parse(readFileSync('/tmp/akm-1201-evidence/defaults.json','utf8'));
const sb=sandboxIn(saved.sandbox), rows=[];
for(const build of ['baseline','candidate']) {
 sb.cmd=['bun',build==='baseline'?'/tmp/akm-1201-baseline/src/cli.ts':'<candidate>/src/cli.ts'];
 for(const query of ['thanks, that worked!','a table keeps splitting across two pages in my book layout','Terraform remote state locking with DynamoDB']) {
  const out=await runAkm(sb,['curate','--detail','agent','--format','json','--',query]);
  rows.push({build,query,...out,stdout:JSON.parse(out.stdout)});
 }
}
writeFileSync('/tmp/akm-1201-evidence/default-modes.json',JSON.stringify(rows,null,2));
