import {writeFileSync} from 'node:fs';
const realFetch=globalThis.fetch;
globalThis.fetch=async (input, init)=>{
 const response=await realFetch(input,init);
 if(String(input).includes('/embeddings') && typeof init?.body==='string') {
  writeFileSync(process.env.PROBE_CAPTURE!,JSON.stringify({request:JSON.parse(init.body),response:await response.clone().json()},null,2));
 }
 return response;
};
