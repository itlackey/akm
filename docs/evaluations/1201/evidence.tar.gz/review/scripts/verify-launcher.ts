import {readdirSync,writeFileSync} from 'node:fs';
import {sandboxIn,runAkm} from './lib/akm/akm.ts';
const dir='/tmp/'+readdirSync('/tmp').find(x=>x.startsWith('akm-eval-1201-review-installed-'));
const sb=sandboxIn(dir);sb.cmd=['/tmp/akm-1201-review-installed/node_modules/.bin/akm'];
const rows=[];
for(const [query,flags] of [['Hello!',[]],['Thank you, find both the Aurora focus adjustment and the reticle calibration reference.',[]],['Aurora telescope calibration',['--belief','historical']]] as [string,string[]][]) {
 const r=await runAkm(sb,['curate','--detail','agent','--format','json',...flags,'--',query]);if(r.code) throw Error(r.stderr);rows.push({query,...r,stdout:JSON.parse(r.stdout)});
}
if(rows[0].stdout.items.length || !rows[1].stdout.items.some((x:any)=>x.ref==='knowledge/aurora-focus') || !rows[2].stdout.items.some((x:any)=>x.ref==='memories/aurora-calibration-old'))throw Error('launcher verification failed');
writeFileSync('/tmp/1201-review-launcher.json',JSON.stringify(rows,null,2));console.log('Installed bin launcher: social empty, positive useful, historical labelled');
