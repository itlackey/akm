import {writeFileSync} from 'node:fs';
import {createSandbox,writeConfig,runAkm} from './lib/akm/akm.ts';
import {load} from './evals/retrieval/src/akm.ts';
const sb=createSandbox('1201-review-installed');
const cli=['bun','/tmp/akm-1201-review-installed/node_modules/akm-cli/dist/cli.js'];
sb.cmd=cli;
writeConfig(sb,{configVersion:'0.9.0',registries:[]});
await load(sb,'/tmp/akm-eval-1201/private/retrieval/1201-final/library');
const rows=[];
for(const [query,options] of [
 ['yes',{}],['LGTM!',{}],['ok do it',{}],['continue please',{}],['thanks so much',{}],['hi there!',{}],
 ['Hello!',{}],['THANK YOU!!',{}],['Okay, sounds good.',{}],['Hi, ready when you are.',{}],
 ['Thank you, find both the Aurora focus adjustment and the reticle calibration reference.',{}],
 ['Aurora telescope calibration',{belief:'historical'}],
 ['Aurora telescope calibration',{belief:'all'}],
 ['Aurora telescope calibration',{filters:{user:'absent'}}],
] as [string,any][]) {
 const flags=[...(options.belief?['--belief',options.belief]:[]),...(options.filters?['--filter','user=absent']:[])];
 sb.cmd=cli;
 const raw=await runAkm(sb,['-q','--detail','agent','curate','--format','json',...flags,'--',query]);
 if(raw.code) throw Error(raw.stderr);
 const out=JSON.parse(raw.stdout), refs=out.items.map((x:any)=>x.ref);
 for(const runtime of ['bun','node']) {
  sb.cmd=[runtime,'/tmp/akm-1201-review-installed/api-call.mjs'];
  const api=await runAkm(sb,[query,JSON.stringify({format:'json',...options})]);
  if(api.code || api.stdout!==raw.stdout) throw Error('CLI/API mismatch '+runtime+' '+query+' '+api.stderr);
 }
 sb.cmd=cli;
 const pack=await runAkm(sb,['-q','--detail','agent','curate','--pack','4000',...flags,'--',query]);
 if(pack.code) throw Error(pack.stderr);
 if(options.belief==='historical' && (!refs.includes('memories/aurora-calibration-old') || out.items.some((x:any)=>!x.reason.includes('Historical context')))) throw Error('historical missing');
 if(!options.belief && (JSON.stringify(out).includes('"ref":"memories/aurora-calibration-old"') || pack.stdout.includes('lock focus before sunset'))) throw Error('stale authority');
 if(query.startsWith('Thank you,') && !['knowledge/aurora-focus','knowledge/aurora-calibration'].every(x=>refs.includes(x))) throw Error('missing evidence');
 if((['yes','LGTM!','ok do it','continue please','thanks so much','hi there!'].includes(query) || query==='Hello!' || query==='THANK YOU!!' || query==='Okay, sounds good.' || query==='Hi, ready when you are.' || options.filters) && refs.length) throw Error('expected abstention');
 rows.push({query,options,stdout:out,pack:JSON.parse(pack.stdout),cliApiParity:['bun','node'],ms:raw.ms});
}
sb.cmd=cli;
const search=await runAkm(sb,['search','hello','--detail','agent','--format','json']);
if(search.code || !JSON.parse(search.stdout).hits.some((x:any)=>x.ref==='knowledge/console-handshake')) throw Error('deliberate search unavailable');
writeFileSync('/tmp/1201-review-installed.json',JSON.stringify({config:{configVersion:'0.9.0',registries:[]},rows,search:JSON.parse(search.stdout)},null,2));
console.log('14 installed cases pass, Bun/Node API byte parity, current/historical/all/scope and packed evidence verified');
