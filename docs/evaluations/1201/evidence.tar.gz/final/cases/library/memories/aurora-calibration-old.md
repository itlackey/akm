---
description: "Aurora telescope calibration obsolete fixed focus method."
beliefState: "superseded"
---

# Old calibration

Historical procedure: lock focus before sunset and skip reticle verification. Superseded by the current calibration reference.
