---
description: "Aurora telescope photo color balance and display saturation."
---

# Color balance

Adjust display saturation for aurora photographs. This display setting does not correct telescope focus or reticle alignment.
