---
description: "Aurora telescope reticle calibration reference after thermal focus adjustment."
beliefState: "active"
---

# Reticle calibration

Record the reference star position at the center of the reticle. Verify alignment after thermal focus adjustment. Keep both the focus procedure and calibration record.
