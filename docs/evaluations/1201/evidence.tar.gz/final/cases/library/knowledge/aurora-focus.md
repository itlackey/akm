---
description: "Aurora telescope thermal focus drift: blurry stars after sunset."
xrefs: ["knowledge/aurora-calibration", "memories/aurora-calibration-old"]
---

# Thermal focus adjustment

For blurry stars after sunset, wait for thermal equilibrium, then adjust focus on a reference star. Use the calibration reference to verify the reticle after the focus adjustment.
