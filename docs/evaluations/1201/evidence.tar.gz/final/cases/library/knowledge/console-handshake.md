---
description: "Hello startup console handshake prints hello, thank you, okay sounds good and ready when you are."
---

# Startup handshake

The console prints hello during its startup handshake and accepts the diagnostic strings thank you, okay sounds good and ready when you are. This is a protocol reference, not a reply to conversational turns.
