# #1201: one additional lexical ranking experiment

Status: **rejected**. The ranking change was removed. PR #1207 remains the selected implementation at 60506def.

The user requested further recall/banned-case experiments and selected keeping ranking work separate under #1201. Baseline is the validated #1199 candidate, 60506defa0fcfb96d76ad1e7a1f22af6c8e66c5e. This is candidate variant **3 of 3** across the task, not a new budget. Prior collector invocations: 10 of 12 (8 valid, 2 setup failures). Reserve one bounded paired pilot and one full public collection; cap additional measurement at 20 minutes, excluding repository checks. No additional variants or parameter sweeps.

## Observation and hypothesis (before tuning)

Books has 12/51 keyword and 8/51 semantic-curate banned-above-useful cases after #1199. Three keyword first-result failures are exact-name assets outranked by description/body keyword repetition: renal nephron function, beurre noisette technique, statute of limitations overview. All lexical columns currently have equal BM25 weight despite the existing documented field-priority intent. Other failures include wrong-domain overlap and reference text labelled banned in favor of nearly identical pinned/lesson text. Labels stay fixed: this experiment does not claim to resolve factual truth or infer authority from type/belief labels.

Test one change: increase the existing name column's BM25 weight from 1 to 4, keeping every other column at 1. This gives an asset's declared name more influence than incidental repetition. The factor is one preselected treatment, not a fitted optimum. Keep RRF, feedback, tokenization, eligibility, vectors, reranker, abstention, packing and configuration unchanged. No index-format or reindex requirement.

## Ordered acceptance and stopping criteria

1. Block on scope/current/historical/support/packed-content eligibility regressions, CLI/API errors, or failed required AKM checks.
2. Worthwhile benefit: at least two fewer keyword banned-above-first cases in books (8/51 after #1199; corrected from 9 by counting saved rows before viewing pilot results); no increase in semantic banned-above-useful, and inspect every newly lost useful result.
3. Both public collections: no >0.005 absolute nDCG decrease per primary search/semantic-curate arm; no loss of success@5, and no material stable useful-recall regression. A per-case recall loss of >=0.2 requires investigation and blocks acceptance unless explained as bounded and justified; do not hide losses in an average.
4. Existing no-answer/non-task false-abstention behavior must not worsen. Warm median query latency within 10% or inspect timing noise; no new model calls, packed-content expansion or indexing cost by design.
5. Reserve untouched, independently authored progressive retrieval and Markdown-fragment tests as final canaries. Existing public semantic results use remote lab embeddings, not an answer/judge model. Existing labels are fixed; review new task-query pairs consistently and explicitly rescore both saved baseline and candidate if adding judgments.

Reject this variant if its intended benefit is absent or a material unexplained regression remains. If accepted, validate the installed build and stop. Report rollout as pending; no merge or deployment is authorized.

## Final decision and evidence

Reject variant 3. It reduces only one banned-above-first case, below the predeclared minimum of two. The improvement is the conflict-check house fact moving above an almost identical reference, not the three exact-name failures that motivated this treatment. Those exact-name failures all remain. No fourth variant or parameter sweep was attempted.

The baseline for this experiment is #1199's selected current-default build, not the earlier all-default release baseline. Newly surfaced task pairs were reviewed on the same 0–3 usefulness rubric; 12 library labels and one books label were added, no existing grade changed. **Both saved runs were explicitly rescored**. `baseline-*/` and `candidate-*/` hold those scores. `candidate-*-raw/` retain original collection scores. This expanded label set changes some #1199 baseline aggregates, so use the paired numbers below rather than subtracting from the earlier report.

| Outcome | #1199 baseline | Name weight 4 |
|---|---:|---:|
| Library keyword recall@10 | 0.7424 | 0.7487 |
| Library keyword nDCG@10 | 0.7559 | 0.7588 |
| Library semantic-curate recall@10 | 0.8079 | 0.8051 |
| Library semantic-curate nDCG@10 | 0.8194 | 0.8196 |
| Books keyword recall@10 | 0.9369 | 0.9369 |
| Books keyword nDCG@10 | 0.8351 | 0.8403 |
| Books keyword banned above useful | 12/51 | 11/51 |
| Books keyword banned above first useful | 8/51 | 7/51 |
| Books semantic-curate recall@10 | 0.9877 | 0.9877 |
| Books semantic-curate banned above useful | 8/51 | 8/51 |

Success@5 is unchanged in every arm (library keyword 98/101, semantic 99/101; books keyword 51/51, semantic 50/51). No-answer curate abstention remains 0/10, and non-task curate abstention remains 1/25. These poor abstention results are unresolved #1201 work, not a success claim. No command errors or fallbacks occurred in the full run: all 187 cases completed in all four columns, with reported keyword/semantic modes matching the harness configuration. No answer or judge model ran.

### Per-case losses and limits

No keyword useful-recall case decreased in either collection. Library semantic-curate lost one useful top-ten asset on q020 (ink coverage, 6/7 to 5/7) and q088 (docs after refactor, 7/7 to 6/7). Semantic search additionally lost tracker-cli on q059 (2/3 to 1/3), while curate retained it. `analysis.json` lists every changed result and loss. `loss-inspect.json` checks the same cached index without model calls: target lexical positions on q020/q088 did not change; tracker-cli on q059 moved from lexical rank 42 to 43. Earlier unchanged-build q059 observations were all 2/3, so the new 1/3 must not be dismissed as established noise. No repeat was spent resolving causality because the deterministic primary acceptance criterion already failed and the experiment budget was exhausted. The semantic loss remains an additional reason not to accept this treatment.

All newly surfaced task pairs have judgments after review; older unchanged unjudged semantic results remain (library semantic-curate judged coverage 83.27%, books 89.22%). These retrieval metrics do not establish downstream answer accuracy or factual truth. The books authority-sensitive labels were preserved even where reference and pinned text are nearly identical. Additional ranking work needs to address real user authority/usefulness outcomes rather than merely fitting those labels.

Warm median CLI times were 0.21/0.27 seconds for keyword search/curate in both collections versus 0.23/0.29 baseline. Semantic-curate medians were 0.29 versus 0.31 seconds (library), 0.30 versus 0.33 (books). Unpaired sequential host timing is too weak to claim a speedup. Cold semantic indexing took 9.6 seconds (library) and 5.6 seconds (books); full collection wall time was 151.47 + 62.07 seconds. Packed-token cost and installed-candidate behavior were not separately measured after rejection; rank changes can alter packed cost even without changing the packer.

### Checks, budget, recovery and rollout

- Focused field-weight/curate eligibility: **29 pass, 0 fail**.
- Reserved independently authored progressive/Markdown retrieval canaries: **25 pass, 0 fail**.
- The paired pilot had 12 valid semantic observations with unchanged rankings and 12 invalid keyword observations caused by a harness configuration mistake. Invalid observations are excluded, with the raw error evidence retained. Its null banned metrics also omitted the scorer's banned argument and are not used.
- Total product variants: **3/3**, best validated variant remains #1199 variant 2. Two additional measurement slots consumed: one helper pilot and one full collector invocation. Across the task: 11 collector invocations (9 valid, 2 prior setup failures) plus this paired pilot; no further collection is authorized by the original 12-slot budget.
- The rejected source diff is saved in `rejected-variant.patch`; the live source file was restored to 60506def. Only the separate experiment record/evidence remains in this branch. No new release checks or installed-candidate claim is needed for a removed product change. #1199's accepted full-suite/install evidence remains unchanged.
- Recovery is already complete: product code matches the validated #1199 build. No migration/reindex is needed. No change was pushed to PR #1207, merged, published, or deployed. #1199 rollout remains with the release maintainer; this #1201 experiment has no rollout action.

The additional experiment found a small keyword improvement, not a sufficiently supported combined improvement to ship. Iteration stopped at the predeclared acceptance failure and the three-variant cap, preserving the validated candidate. Another treatment requires a newly authorized experiment budget and a hypothesis stronger than increasing a global name weight.

## Artifact notes

`commands.md` records exact invocations, `compare-*.md/json` are existing akm-eval comparison reports, `analysis.json` contains per-case deltas, and `*-labels.jsonl` contain the 13 new judgments. Summary JSON copies redact the private embedding endpoint and environment key reference; originals remain in the temporary evaluator checkout. Model is the same configured remote lab `embed/qwen3-embedding-0.6b` (1024 dimensions), semantic search enabled, no answer/judge model. The private evaluator overlay was not changed or published. Pilot scripts read the existing private sandbox config rather than embedding endpoint credentials.
